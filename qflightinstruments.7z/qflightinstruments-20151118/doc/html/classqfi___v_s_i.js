var classqfi___v_s_i =
[
    [ "qfi_VSI", "classqfi___v_s_i.html#a30c33393166e133182e9d87e616b8bed", null ],
    [ "~qfi_VSI", "classqfi___v_s_i.html#abe27388fca9989bcc65a099347fdf7e2", null ],
    [ "reinit", "classqfi___v_s_i.html#a8547a58e7f09648e8f001746f49834af", null ],
    [ "resizeEvent", "classqfi___v_s_i.html#afceffeec210b1dd112bfcf7f18dcd36c", null ],
    [ "setClimbRate", "classqfi___v_s_i.html#ae57ff5ac08cfa4bdbe518dd6da5551ea", null ],
    [ "update", "classqfi___v_s_i.html#af327c2ebd69f720e2d2b7c5f5a44d58b", null ]
];