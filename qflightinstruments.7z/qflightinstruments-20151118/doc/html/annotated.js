var annotated =
[
    [ "qfi_ADI", "classqfi___a_d_i.html", "classqfi___a_d_i" ],
    [ "qfi_ALT", "classqfi___a_l_t.html", "classqfi___a_l_t" ],
    [ "qfi_ASI", "classqfi___a_s_i.html", "classqfi___a_s_i" ],
    [ "qfi_HSI", "classqfi___h_s_i.html", "classqfi___h_s_i" ],
    [ "qfi_NAV", "classqfi___n_a_v.html", "classqfi___n_a_v" ],
    [ "qfi_PFD", "classqfi___p_f_d.html", "classqfi___p_f_d" ],
    [ "qfi_TC", "classqfi___t_c.html", "classqfi___t_c" ],
    [ "qfi_VSI", "classqfi___v_s_i.html", "classqfi___v_s_i" ]
];